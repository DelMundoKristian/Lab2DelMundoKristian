package com.example.lab2delmundokristian;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText et1, et2, et3, et4, et5, et6, et7,et8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = findViewById(R.id.editText);
        et2 = findViewById(R.id.editText2);
        et3 = findViewById(R.id.editText3);
        et4 = findViewById(R.id.editText4);
        et5 = findViewById(R.id.editText5);
        et6 = findViewById(R.id.editText6);
        et7 = findViewById(R.id.editText7);
        et8 = findViewById(R.id.editText8);
    }
    public void savedata(View v){
        SharedPreferences sp = getSharedPreferences("mydata" , MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        String e1 = et1.getText().toString();
        String e2 = et2.getText().toString();
        String e3 = et3.getText().toString();
        String e4 = et4.getText().toString();
        String e5 = et5.getText().toString();
        String e6 = et6.getText().toString();
        String e7 = et7.getText().toString();
        String e8 = et8.getText().toString();
        editor.putString("course1", e1);
        editor.putString("course2", e2);
        editor.putString("course3", e3);
        editor.putString("course4", e4);
        editor.putString("course5", e5);
        editor.putString("course6", e6);
        editor.putString("course7", e7);
        editor.putString("course8", e8);
        editor.commit();
        Toast.makeText(this,"data was saved....", Toast.LENGTH_LONG).show();
    }
    public void next(View v){
        Intent intent = new Intent(getApplicationContext(),Validate.class);
        startActivity(intent);
    }
}
