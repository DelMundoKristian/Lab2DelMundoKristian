package com.example.lab2delmundokristian;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Validate extends AppCompatActivity {
    EditText et;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validate);
        et = findViewById(R.id.editText9);
    }
    public void validate(View v){
        SharedPreferences sp = getSharedPreferences("mydata" , MODE_PRIVATE);
        String sp1 = sp.getString("course1",null);
        String sp2 = sp.getString("course2", null);
        String sp3 = sp.getString("course3",null);
        String sp4 = sp.getString("course4", null);
        String sp5 = sp.getString("course5",null);
        String sp6 = sp.getString("course6", null);
        String sp7 = sp.getString("course7",null);
        String sp8 = sp.getString("course8", null);
        String etx = et.getText().toString();
        if(etx.equals(sp1)||etx.equals(sp2)||etx.equals(sp3)||etx.equals(sp4)||etx.equals(sp5)||etx.equals(sp6)||etx.equals(sp7)||etx.equals(sp8)){
            Toast.makeText(this, "There is already a course with that name", Toast.LENGTH_LONG).show();

        }
        else{
            Toast.makeText(this, "There is no course saved with that name", Toast.LENGTH_LONG).show();

        }
    }
    public void next2(View v){
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
    }
}
